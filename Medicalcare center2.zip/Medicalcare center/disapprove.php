<?php

include_once("DBHelper.php");


$db=new DBHelper();
$conn=$db->connect();
$sql=" Delete From users where ID ='4'";
if( mysqli_query($conn,$sql))
header("refresh:1; url=SeeUpdateRequests.php");

?>