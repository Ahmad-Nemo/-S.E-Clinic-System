<html>
<head>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/all.min.css">
  <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/signin_style.css">
    
    
    </head>
    
<?php
    session_start();
     
   include_once("connection.php");
     
     if(!$conn)
     {
     die("Connection failed: ".mysqli_connect_error());
     }
     if(isset($_SESSION["Adminloggedin"]))
     {
    header("Location:Admin.html");
     }
     if(isset($_SESSION["Doctorlogin"]))
     {
    header("Location:Doctor.html");
     }
    if(isset($_SESSION["secertairylogin"]))
    {
    header("Location:index.html");
    }
    $Error="";


    
    

    
    
    
    if(isset($_POST["Submit"]))
    {
        $username = $_POST['username'];
        $password = $_POST['upassword'];
        $_SESSION['username']=$username;
        $_SESSION['Password']=$password;
        
        if(isset($_POST["remember"]))
        {  
         include_once("cookies.php");
        }
       

        $sql="SELECT * FROM users WHERE Email = '$username' AND Password ='$password'";
        $sql2="SELECT TypeID FROM users WHERE Email ='$username'";
        $sql3="SELECT status FROM users WHERE Email ='$username'";
        
	    $result = mysqli_query($conn,$sql);
        $result2 = mysqli_query($conn,$sql2);
        $result3 = mysqli_query($conn,$sql3);
       // $result4 = mysqli_query($conn,$sql4);
        if($row3=mysqli_fetch_array($result3))
        {
            $_SESSION["userstatus"]=$row3[0];
        }
        if($row2=mysqli_fetch_array($result2))            
        {
              $_SESSION["usertype"]=$row2[0];
        }
        
        if($row=mysqli_fetch_array($result))	
	    {
            if($_SESSION["userstatus"]=="pending")
            {
                $Error= "You are not approved yet";       
            }
            else if($_SESSION["userstatus"]=="Declined")
            {
                
                $Error= "sorry you  are declined, please contact us for further information";
            }
            else 
            {
                
                 $_SESSION["ID"]=$row[7];
                  $_SESSION["Fname"]=$row[0];
                  $_SESSION["Lname"]=$row[1];
                  $_SESSION["Umail"]=$row[2];
                  
              
               
                if($_SESSION["usertype"] == 0)
                { 
                  $_SESSION['Adminloggedin'] = true;
                  header("Location:Admin.html");
                    
                }
                else if($_SESSION["usertype"] == 1)
                {
                   
                    $_SESSION["doctorlogin"]=true;
                    header("Location:Doctor.html");
                }
                else if($_SESSION["usertype"] == 2)
                {
                    $_SESSION["secertairylogin"]=true;
                    header("Location:index.html");
                } 
            }  
	    }
	    else	
	    {
		 $Error= "Invalid username or Password";
        }
     
        
    }
    if(!isset($_COOKIE['Username']))
    {
        $_COOKIE['Username']=" ";
        
    }
   if(!isset($_COOKIE['Password']))
    {
        $_COOKIE['Password']=" ";
        
    }
    
    
    ?>
    
    
    <script src="js/wow.min.js"></script>
    <script>
              new WOW().init();
        
    </script>
    
<body>
<?php include"header.php";?>

<form action="" method="post">
  <div class="imgcontainer wow fadeIn">
    
      <div class="line"></div>
  </div>
  <div class="container">
      <h2 class="title wow flipInX" data-wow-delay="0.5s">Sign In</h2>
      <?php echo "<h4 style='color: red'>".$Error."</h4>"; ?>
    <label for="uname"><b>Email</b></label><br>
    <input type="text" class="form-control" placeholder="Enter Username" value="<?php echo $_COOKIE['Username'] ?>" id="uname" name="username" required><br>

    <label for="psw"><b>Password</b></label><br>
    <input type="password" class="form-control" placeholder="Enter Password" value="<?php echo $_COOKIE['Password'] ?>" id="pass" name="upassword" required><br><br>
        
    <button class="btn mybtn" name="Submit" type="submit">Login</button><br>
    <label>
      <input type="checkbox" checked="checked" class="form-check-label" name="remember"> Remember me
    </label>
      
  </div>

</form>
    <script>
      document.getElementById("uname").focus();
        
    </script>
    

</body>
</html>