<?php
		if(!empty($_SESSION['ID']))
		
		{ 
			
			include_once("usertypes.php");

			
		
			//echo"<li>Welcome </li> ".$_SESSION['name'];
			$usertype=new usertypes();
			$usertypeid=$usertype->getusertypes();
			
			if ($usertypeid==0) {
				
			/*	echo"<li><a href='showrequests.php'>show request</a></li>";
				echo"<li><a href='search.php'>Search</a></li>";
				echo"<li><a href='edit.php'>Edit Account</a></li>";	
				echo"<li><a href='request.php'>Apply Request</a></li>";	
				echo"<li><a href='Faq.php'>Help page</a></li>";
				echo"<li><a href='SignOut.php'>SignOut</a></li>";
				*/
				header("location:Admin.php");
			}
			if ($usertypeid==1) {

				/*
				echo"<li><a href='SeeRequests.php'>See Request</a></li>";
				echo"<li><a href='EditForm.php'>edit help page</a></li>";
				echo"<li><a href='SeeUpdateRequests.php'>See update request</a></li>";
				echo"<li><a href='TheHRLetter.php'>See HR letter request</a></li>";
				echo"<li><a href='ADDHR.php'>Add HR </a></li>";
				echo"<li><a href='SignOut.php'>SignOut</a></li>";
				
*/				
				header("location:Doctor.php");
				
			}

			if ($usertypeid==2) {

				
				/*
				
				echo"<li><a href='showcomments.php'>Show comments</a></li>";
				echo"<li><a href='review.php'>Add Comment</a></li>";
				echo"<li><a href='SignOut.php'>SignOut</a></li>";
			*/	
			header("location:index.php");
			}

			if ($usertypeid==3) {

				
				/*
				
				echo"<li><a href='showcomments.php'>Show comments</a></li>";
				echo"<li><a href='review.php'>Add Comment</a></li>";
				echo"<li><a href='SignOut.php'>SignOut</a></li>";
			*/	

			header("location:Secretary.php");
			}

		}
?>
 
	