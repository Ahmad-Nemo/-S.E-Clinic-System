<?php 
$_SESSION['ID'];
$_SESSION['name'];
$_SESSION['password'];
$_SESSION['email'];
$_SESSION['isApproved'];
?>