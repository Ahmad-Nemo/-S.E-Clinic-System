<?php
include_once("DBHelper.php");
$db=new DBHelper();
$con=$db->connect();

 
$sql = "Select user.name,requesttype.name\n"

    . "from user INNER JOIN requesttype\n"

    . "on user.id=requesttype.id";
$term =  $_POST['term'];
  echo"<table class='table table-striped table-hover'>
            <tr><th>name</th><th>request name</th><th>yes</th><th>no</th></tr>";
if(!empty($term)){
    // Attempt select query execution
    $sql = $sql."WHERE name LIKE '%" . $term . "%' or request.name LIKE '%" . $term . "%'";
}
    if($result = mysqli_query($con, $sql)){
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                if($row["status"]==1)
                     echo"<'button' class='btn btn-primary'>";
                else
                     echo"<tr>";

                echo "<td>" . $row['FirstName'] . "</td><td>". $row['LastName'] ."</td><td>".$row["name"]."</td><td>";
            }
            
        } else{
            echo "<tr><td colspan=4>No matches found</td></tr>";
        }
    } else{
        echo "<tr><td colspan=4>ERROR: Could not able to execute $sql. " . mysqli_error($con)."</td></tr>";
    }

 echo"</table>";
// close connection
mysqli_close($con);
?>