<html>
<?php
include_once("DBHelper.php");
session_start();
 $db=new DBHelper();
$conn=$db->connect();

    $sql="Select * from users where status = 'pending' ";
    $result = mysqli_query($conn,$sql);	
?>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>



<body>
<div class="container">
  
  <h2>Regiester Table</h2>
  <div class="table-condensed table-bordered">          
  <table class="table" id="myTable">
    <thead>
      <tr>
       <th></th>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
     
        <th>Approve</th>
        <th>Disapprove</th>
       
      </tr>
      <?php
      $db=new DBHelper();
      $conn=$db->connect();
      $sr=1;
      while($row=mysqli_fetch_array($result)){
        if (isset($_POST['approve'])) {
        
     
          // $db=new DBHelper();
          // $conn=$db->connect();
       /* $sql=" UPDATE user set isApproved  = true where id='".$row['id']."'";
          $result = mysqli_query($conn,$sql);

          $sql="Select * from user where usertypeid = 2 and isApproved =0  ";
          $result = mysqli_query($conn,$sql);
          */
        }
       // die();
      
          # code...
        
        ?>
    <tr>
      <form action=""method="post" >
        <td> <?php echo $sr;?></td>
        <td> <?php echo $row['FirstName'];?></td>
        <td> <?php echo $row['Email'];?></td>
        <td> <?php echo $row['Password'];?></td>
        <?php echo "<td><a href=update2.php?id=".$row['ID'].">Approve  </a> </td>";?>
         <?php echo "<td><a href=disapprove.php?id=".$row['ID'].">Disapprove  </a> </td>";?>
        
     
     
      
      </form>
      </tr>
      <?php $sr++;}
      ?>       
  
  </table>
  </div>
</div>

</body>

</html>
<!-- <script>


   /* var values = new Array();
values[0] = ["1","Kiku", "555 5th ave, New York, NY 11355"];
values[1] = ["2","Yamoto", "444 6th ave, New York, NY 11355"];
values[2]=["2","Yamoto", "444 6th ave, New York, NY 11355"];*/
var values=WaitApproveSaveAtTable();
var mixed = document.getElementById("myTable");

  // IE7 only supports appending rows to tbody
  var tbody = document.createElement("tbody");

  // for each outer array row
  for (var i = 0 ; i < values.length; i++) {
     var tr = document.createElement("tr");

     // for each inner array cell
     // create td then text, append
    
    
     for (var j = 0; j < values[i].length; j++) {
       var td = document.createElement("td");
       var txt = document.createTextNode(values[i][j]);
       
       td.appendChild(txt);
       tr.appendChild(td);
      
       if(j==2){
        var td = document.createElement("td");
        var btn = document.createElement("BUTTON");
        btn.id=j+i;
       btn.innerHTML = "Aprove";
       td.appendChild(btn);
       tr.appendChild(td);
       }
      
      
     }
     
     
     // append row to table
     // IE7 requires append row to tbody, append tbody to table
     tbody.appendChild(tr);
     mixed.appendChild(tbody);
   }


</script>

 -->


