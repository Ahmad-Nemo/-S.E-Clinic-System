<?php

// include("classes\Sessions.php");
include_once("DBHelper.php");
session_start();
class User extends DBHelper{
    

    public function __construct()
    {
        // $db=new DBHelper();
        // $conn = $db->connect();
      //  session_start();
    }



    public function viewSignup()
    {
        include 'signup.php';
    }   
   /* public function WaitApproveSaveAtTable($array,$name,$email,$password)
{
    //kol lma dh ttndh t add new row l 2d array w tb3t al array l java scrip w b3d mattb3t trbot al id bt3ha b id botton w lma button ydas 3lyh t call remove from 2d array w tcall  RegiesterEmployee aly t7t klam dh
    $array2= array ($name,$email,$password);
    array_push($array, $array2);
   return $array;

}
 */

    public function RegiesterEmployee($name,$email,$DOB,$password)
    {   
        
        $db=new DBHelper();
        
        
        
        $sql="INSERT INTO user(name,email,password,DOB,isApproved,usertypeid) values('".$name."','".$email."','".$password."','".$DOB."',0,2)";
       // var_dump($sql);
        $result=$db->connect()->query($sql);
        return $result;
    
    }
    public function regiesterHr($name,$email,$password){
        $db=new DBHelper();
        $sql="INSERT INTO user(name,email,password,usertypeid) values('".$name."','".$email."','".$password."',1)";
        $result=$db->connect()->query($sql);
        return $result;
        
    }
    public function regiesterQc($name,$email,$password){
        $db=new DBHelper();
        $sql="INSERT INTO user(name,email,password,usertypeid) values('".$name."','".$email."','".$password."',3)";
        $result=$db->connect()->query($sql);
        return $result;
        

    }

    public function getallemployee(){
        
        $sql='SELECT * FROM user where usertypeid = 2';
        $result=$this->connect()->query($sql);

        $numrows=$result->num_rows;
            if ($numrows >0)
            {
                while ($row =$result->fetch_assoc()) {
                        $data[]=$row;
                    
                }
                return $data;
                # code...
            }


        return $sql;
    }
    public function login($email,$password){
            //session_start();
        $db=new DBHelper();
        $conn=$db->connect();
        
            $sql="Select * from user where Email ='".$email."' and Password='".$password."'";
            $result = mysqli_query($conn,$sql);	
        
            if($row=mysqli_fetch_array($result))	
            {
                $_SESSION["ID"]=$row["id"];
                $_SESSION["name"]=$row["name"];
                $_SESSION["email"]=$row["email"];
                $_SESSION["password"]=$row["password"];
                //$_SESSION["isApproved"]=$row["isApproved"];
                
                header("Location:home.php");
                
            }
            else	
            {
                echo "Invalid Email or Password";
            }

        
    }
//     public function edituser($name,$email,$password)
//     {
        
          
//         $db=new DBHelper();
//         $conn=$db->connect();
        
         
//       //  session_start();
//     //   $sql=" UPDATE user set name = '".$name."' , email = '".$email."' , password= '".$password."' where id= '".$_SESSION['ID']."'";

//       //$sql=" UPDATE user set isApproved  = true where id='".$row['id']."'";
        
        
        
//       $result=mysqli_query($conn,$sql);
      
//      return $result;
//     //     if ($row=mysqli_fetch_array($result))			
//     //     {
//     //        $row=$_SESSION["name"]=$_POST[$name];
//     //         $row=$_SESSION["email"]=$_POST[$email];
//     //         $row=$_SESSION["password"]=$_POST[$password];
//     //         $row=$_SESSION["isApproved"]=true;
//     //         echo "recored updated successfully";
//     //         header("Location:home.php");
//     //         $conn->close();
//     //     }

//     //     else
//     //     {
//     //         echo ("Could not insert data : " . mysqli_error($result) . " " . mysqli_errno($conn));
//     // }


// }
public function selectallusers(){
    $db=new DBHelper();
$conn=$db->connect();

    $sql="Select * from users where status = 2 and isApproved =0  ";
    $result = mysqli_query($conn,$sql);	
  
    return $result;
}
public function selectallusersthree(){
    $db=new DBHelper();
$conn=$db->connect();

    $sql="Select * from user where usertypeid = 2 and isApproved =1  ";
    $result = mysqli_query($conn,$sql);	
  
    return $result;
}
public function fetchrequesttype(){

         $Db= new DBHelper();
         $conn=$Db->connect();	
         $sql="SELECT name FROM requesttype";
         $result = mysqli_query($conn,$sql);
         
         

        return $result;

}
public function insertrequestEmbassy($to,$address,$company,$requesttypename,$status,$priority,$userid,$salary){
    $userid=$_SESSION['ID'];
    $status=0;
    
//    insert into "order" (customer_id, price) values \
//((select customer_id from customer where name = 'John'), 12.34);
    $db=new DBHelper();
    $conn=$db->connect();
   // $sql1="select id from requesttype where id = '".$requesttypeid."'";
    $sql="INSERT INTO  request (sendto,address,company,requesttypename,status,priority,userid,salary) Values('".$to."','".$address."','".$company."','".$requesttypename."', 0 ,'".$priority."' ,'".$userid."','".$salary."')"; 
    // $sql="INSERT INTO  request (sendto,address,company,requesttypename,status,priority,userid,salary) Values('".$to."','".$address."','".$company."','".$requesttypename."', 0 ,'".$priority."' ,'".$userid."','".$salary."')"; 
 
   
   
    
    $result=(mysqli_query($conn,$sql));
    return $result;

    // $sql="INSERT INTO user(name,email,password,DOB,isApproved,usertypeid) values('".$name."','".$email."','".$password."','".$DOB."',0,2)";
}
public function insertrequestgeneral($to,$address,$company,$requesttypeid,$status,$priority,$userid,$salary){
$userid=$_SESSION['ID'];
$db=new DBHelper();
$conn=$db->connect();
}

public function selectalluserRequest(){
    $db= new DBHelper();
    $conn=$db->connect();
    $sql= " SELECT * From request WHERE userid = '".$_SESSION['ID']."'";
  
    $result=mysqli_query($conn,$sql);
    return $result;
}
public function selectallusersRequests(){
    $db= new DBHelper();
    $conn=$db->connect();
    $sql= " SELECT * From request JOIN user on request.userid = user.id where status = 0 ";
    $result=mysqli_query($conn,$sql);
    return $result;
}
public function updaterequest($sendto,$address,$company,$requesttypename,$priority,$salary){
$id=
$db=new DBHelper();

}
public function deleterequest($id){
    $db =new DBHelper();
    $conn=$db->connect();
    $sql="DELETE FROM MyGuests WHERE id='".$id."'";
    if ($conn->query($sql)==true) 
    {
    echo "record deleted";
    //$user=new User();
    //$user->selectallusers();
    }
    $conn->close();

}
public function getusertypeid(){
    $db=new DBHelper();
    $conn=$db->connect();
    $sql="SELECT usertypeid FROM user WHERE id='".$_SESSION['ID']."'";
    $result=mysqli_query($conn,$sql);
    $row = mysqli_fetch_fields($result);
    $usertypeid=$row->usertypeid;


    return $usertypeid;

}
public function selectalluserstwo(){
    $db=new DBHelper();
$conn=$db->connect();

    $sql="Select * from user2";
    $result = mysqli_query($conn,$sql);

    return $result;
}
}

?>
